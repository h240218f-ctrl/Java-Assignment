import java.io.FileWriter;
import java.io.IOException;

abstract class Bank {
    protected String accountName;
    protected double balance;

    public Bank(String accountName) {
        this.accountName = accountName;
        this.balance = 0.0;
    }

    abstract void deposit(double amount);
    abstract void withdraw(double amount);
    abstract double getBalance();
}

class Account extends Bank {
    public Account(String accountName) {
        super(accountName);
    }

    @Override
    void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            recordTransaction("Deposited: " + amount);
        }
    }

    @Override
    void withdraw(double amount) {
        if (amount > balance) {
            System.out.println("Withdrawal amount exceeded account balance");
        } else {
            balance -= amount;
            recordTransaction("Withdrew: " + amount);
        }
    }

    @Override
    double getBalance() {
        return balance;
    }

    private void recordTransaction(String transaction) {
        try (FileWriter writer = new FileWriter("Bank.txt", true)) {
            writer.write(accountName + ": " + transaction + "\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

class AccountTest {
    public static void main(String[] args) {
        Account myAccount = new Account("John Doe");
        myAccount.deposit(500);
        myAccount.withdraw(200);
        System.out.println("Current Balance: " + myAccount.getBalance());
        myAccount.withdraw(400); // Exceeds balance
    }
}
