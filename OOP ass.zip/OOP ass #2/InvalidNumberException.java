package assignment;


/**
 * A simple custom checked exception.
 */
public class InvalidNumberException
extends Exception {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidNumberException(String message) {
        super(message);
    }
}

