package assignment;


public class CustomExceptionDemo {

    // Method declares it throws the custom checked exception
    public static void checkNumber(int n) throws InvalidNumberException {
        if (n < 0) {
            // Throw the custom exception with a helpful message
            throw new InvalidNumberException("Invalid number: " + n + ". Only non-negative numbers are allowed.");
        } else {
            System.out.println("Number " + n + " is valid.");
        }
    }

    public static void main(String[] args) {
        int[] testNumbers = {10, -5, 0};

        for (int n : testNumbers) {
            try {
                checkNumber(n);
            } catch (InvalidNumberException e) {
                // Handle the custom exception
                System.err.println("Caught custom exception: " + e.getMessage());
            }
        }
    }
}