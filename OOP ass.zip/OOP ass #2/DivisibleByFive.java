package assignment;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class DivisibleByFive {
    public static void main(String[] args) {
        List<Integer> numbers = new ArrayList<>(Arrays.asList(1, 4, 5, 20, 30, 6));

        System.out.println("Numbers divisible by 5 (each on its own line):");
        numbers.stream()
               .filter(n -> n % 5 == 0)   // intermediate operation: keep only numbers divisible by 5
               .forEach(System.out::println); // terminal operation: print each result

        // alternative: print in one line
        System.out.print("Same numbers printed on one line: ");
        numbers.stream()
               .filter(n -> n % 5 == 0)
               .forEach(n -> System.out.print(n + " "));
        System.out.println();
    }
}
